function App() {
  return (
    <>
      <h1>Pizza App</h1>
    </>
  );
}

export default App;
