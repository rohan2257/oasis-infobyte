const AuthRoles = {
  ADMIN: "ADMIN",
  USER: "USER",
};
export default AuthRoles;
