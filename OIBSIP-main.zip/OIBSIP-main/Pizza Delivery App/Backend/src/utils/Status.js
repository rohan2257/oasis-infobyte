const Status = {
  ORDERED: "ORDERED",
  SHIPPED: "SHIPPED",
  DELIVERED: "DELIVERED",
  CANCELLED: "CANCELLED",
};
export default Status;
